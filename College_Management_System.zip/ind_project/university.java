import java.util.*;
import java.io.*;

class University1 {
    private static HashMap<String, User> users = new HashMap<>();
    private static final String USER_DATA_FILE = "user_data.txt";
    private static User signedUpUser; // Keep track of the user who signed up in the current session

    public static void main(String[] args) {
        loadUserData();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("------------------- Welcome to University Management System -------------------");
            System.out.println();

            System.out.println("Enter your role (student, teacher, hod, or director) or type 'exit' to exit:");
            String role = scanner.nextLine().toLowerCase();

            switch (role) {
                case "student":
                    studentActions(scanner);
                    break;
                case "teacher":
                    teacherActions(scanner);
                    break;
                case "hod":
                    hodActions(scanner);
                    break;
                case "director":
                    directorLogin(scanner);
                    break;
                case "exit":
                    saveUserData(); // Save user data before exiting
                    System.out.println("Exiting program...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter one of the provided roles.");
            }
        }
    }

    private static void loadUserData() {
        try (BufferedReader br = new BufferedReader(new FileReader(USER_DATA_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userData = line.split(",");
                if (userData.length != 9) {
                    System.out.println("Invalid user data format: " + line);
                    continue; // Skip this line and move to the next one
                }
                String email = userData[0];
                String fullName = userData[1];
                String password = userData[2];
                String role = userData[3];
                int currentSemester = Integer.parseInt(userData[4]);
                String rollNo = userData[5];
                String batch = userData[6];
                String branch = userData[7];
                String studentId = userData[8];
                User user = new User(fullName, password, role, currentSemester, rollNo, batch, branch, studentId);
                users.put(email, user);
            }
        } catch (IOException e) {
            System.out.println("Error loading user data: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error parsing data: " + e.getMessage());
        }
    }

    private static void saveUserData() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(USER_DATA_FILE))) {
            for (User user : users.values()) {
                bw.write(user.toCsv());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving user data: " + e.getMessage());
        }
    }

    private static void studentActions(Scanner scanner) {
        while (true) {
            System.out.println("Student Menu:");
            System.out.println("1. Sign Up");
            System.out.println("2. Login");
            System.out.println("3. Back to Role Selection");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    signUp("student", scanner);
                    break;
                case 2:
                    login("student", scanner);
                    break;
                case 3:
                    return; // Return to role selection
                default:
                    System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }
    }

    private static void teacherActions(Scanner scanner) {
        while (true) {
            System.out.println("Teacher Menu:");
            System.out.println("1. Sign Up");
            System.out.println("2. Login");
            System.out.println("3. Back to Role Selection");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    signUp("teacher", scanner);
                    break;
                case 2:
                    login("teacher", scanner);
                    break;
                case 3:
                    return; // Return to role selection
                default:
                    System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }
    }

    private static void hodActions(Scanner scanner) {
        while (true) {
            System.out.println("HOD Menu:");
            System.out.println("1. Sign Up");
            System.out.println("2. Login");
            System.out.println("3. Back to Role Selection");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    signUp("hod", scanner);
                    break;
                case 2:
                    login("hod", scanner);
                    break;
                case 3:
                    return; // Return to role selection
                default:
                    System.out.println("Invalid choice. Please enter 1, 2, or 3.");
            }
        }
    }

    private static void directorLogin(Scanner scanner) {
        // Default director credentials
        String directorEmail = "director@ljku.edu.in";
        String directorPassword = "director123";

        System.out.print("Enter director email: ");
        String email = scanner.nextLine().toLowerCase();
        System.out.print("Enter director password: ");
        String password = scanner.nextLine();

        if (directorEmail.equals(email) && directorPassword.equals(password)) {
            System.out.println("Welcome Director!");
            // Director actions can be added here
        } else {
            System.out.println("Invalid director credentials.");
        }
    }

    private static void signUp(String role, Scanner scanner) {
        System.out.print("Enter your full name: ");
        String fullName = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        // Generate email ID
        String email = generateEmail(fullName);
        System.out.println("Sign up successful.");
        System.out.println("Your Email id is: " + email);
        System.out.println();
        System.out.println("Enter Your Details Below: ");

        // Additional details for students
        if (role.equals("student")) {
            // Ask for further details
            System.out.print("Enter your current semester: ");
            int currentSemester = scanner.nextInt();
            scanner.nextLine(); // Consume newline character
            System.out.print("Enter your roll number: ");
            String rollNo = scanner.nextLine();
            System.out.print("Enter your batch: ");
            String batch = scanner.nextLine();
            System.out.print("Enter your branch: ");
            String branch = scanner.nextLine();

            String studentId = generateStudentId(branch);
            signedUpUser = new User(fullName, password, role, currentSemester, rollNo, batch, branch, studentId);
            users.put(email, signedUpUser);
            saveUserData(); // Save user data after sign up
            System.out.println("Your student ID is: " + studentId);
            displaySignUpDetails();
            System.out.println();
        } else {
            // Sign up for teacher and HOD
            signedUpUser = new User(fullName, password, role);
            users.put(email, signedUpUser);
            saveUserData(); // Save user data after sign up
            System.out.println();
        }
    }

    private static void displaySignUpDetails() {
        if (signedUpUser != null) {
            System.out.println();
            System.out.println("-------------------------------------------------------------------------- Sign-Up Details --------------------------------------------------------------------------");
            System.out.println();
            System.out.printf("%-30s %-40s %-20s %-20s %-20s %-20s %-20s\n",
                    "Full Name", "Email", "ID", "Semester", "Roll Number", "Batch", "Branch");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------");

            System.out.printf("%-30s %-40s %-20s %-20d %-20s %-20s %-20s\n",
            signedUpUser.getFullName(),signedUpUser.getEmail(), signedUpUser.getStudentId(), signedUpUser.getCurrentSemester(),
                    signedUpUser.getRollNo(), signedUpUser.getBatch(), signedUpUser.getBranch());
                    System.out.println();
                    System.out.println("Login to update your details");
        } else {
            System.out.println("No user signed up in this session.");
        }
    }

    private static String generateEmail(String fullName) {
        String username = generateUsername(fullName);
        return username + "@ljku.edu.in";
    }

    private static String generateUsername(String fullName) {
        String[] names = fullName.split(" ");
        if (names.length >= 2) {
            String firstName = names[0].toLowerCase();
            String lastName = names[names.length - 2].toLowerCase();
            return firstName + "." + lastName;
        } else {
            // If fullName doesn't contain at least two parts, use a default username
            return "default_username";
        }
    }
    
    

    private static String generateStudentId(String branch) {
        Random random = new Random();
        int randomNum = random.nextInt(9000) + 1000; // Generate a 4-digit random number
        return branch.toUpperCase() + randomNum;
    }

    private static void login(String role, Scanner scanner) {
        System.out.print("Enter your email: ");
        String email = scanner.nextLine().toLowerCase();
        if (!users.containsKey(email)) {
            System.out.println("User does not exist.");
            System.out.println();
            return;
        }
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();
        User user = users.get(email);
        if (user.getPassword().equals(password)) {
            System.out.println("Welcome!");
            // Additional actions for students after login can be added here
        } else {
            System.out.println("Incorrect password.");
        }
        System.out.println();
    }

    // Define the User class here
    static class User {
        private String fullName;
        private String email;
        private String password;
        private String role;
        private int currentSemester;
        private String rollNo;
        private String batch;
        private String branch;
        private String studentId;

        public User(String fullName, String password, String role) {
            this.fullName = fullName;
            this.password = password;
            this.role = role;
            generateEmail();
        }

        public User(String fullName, String password, String role, int currentSemester, String rollNo,
                    String batch, String branch, String studentId) {
            this.fullName = fullName;
            this.password = password;
            this.role = role;
            this.currentSemester = currentSemester;
            this.rollNo = rollNo;
            this.batch = batch;
            this.branch = branch;
            this.studentId = studentId;
            generateEmail();
        }

        private void generateEmail() {
            String username = generateUsername(fullName);
            this.email = username + "@ljku.edu.in";
        }

        public String getEmail() {
            return email;
        }
        public String getStudentId()
        {
            return studentId;
        }

        public String getFullName() {
            return fullName;
        }

        public String getRole() {
            return role;
        }

        public int getCurrentSemester() {
            return currentSemester;
        }

        public String getRollNo() {
            return rollNo;
        }

        public String getBatch() {
            return batch;
        }

        public String getBranch() {
            return branch;
        }
        public String getPassword() {
            return password;
        }

        public String toCsv() {
            return email + "," + fullName + "," + password + "," + role + "," + currentSemester + "," +
                    rollNo + "," + batch + "," + branch + "," + studentId;
        }
    }
}
